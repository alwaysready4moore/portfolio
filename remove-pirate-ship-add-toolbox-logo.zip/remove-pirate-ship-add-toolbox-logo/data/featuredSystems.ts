export const featuredSystems = [
  {
    eyebrow: "AI Creative Intelligence Pipeline",
    title: "Aegis",
    description:
      "An independent five-day build that turns competitor landing pages into structured strategy, campaign concepts, and risk-reviewed creative with human judgment built into the workflow.",
    href: "/work/aegis",
    image: "/logos/aegis-logo.png",
    imageAlt: "Aegis Creative Intelligence Pipeline logo.",
    tags: ["AI Product", "Next.js", "Gemini", "Risk Review"],
    theme: "aegis",
  },
  {
    eyebrow: "AI Career Readiness Workflow",
    title: "Launchpad",
    description:
      "A custom Claude skill that turns career readiness into a persistent system with scored gaps, prioritized daily work, progress history, and security-hardened artifacts.",
    href: "/work/launchpad",
    image: "/logos/launchpad-logo.png",
    imageAlt: "Launchpad rocket logo.",
    tags: ["Claude Skill", "Workflow Design", "Persistent State", "Security"],
    theme: "aegis",
  },
  {
    eyebrow: "Embedded Analyst Workflow Tool",
    title: "CSI New Analyst Toolbox",
    description:
      "A browser-based internal tool combining threat-intelligence utilities, embedded guidance, and workflow support to help new analysts work with greater confidence.",
    href: "/work/new-analyst-tool",
    image: "/work/new-analyst.png",
    imageAlt: "New Analyst Toolbox logo.",
    tags: ["Security Operations", "Chrome Extension", "Workflow Design"],
    theme: "toolbox",
  },
] as const;
