This patch:
- Removes Pirate Ship Knowledge Systems from featured systems, Work, search, sitemap, and public routes.
- Removes the Pirate Ship-branded small-win video card and company-specific disclosure.
- Leaves app/resume/page.tsx untouched.
- Changes the New Analyst Toolbox card logo to /work/new-analyst.png.

Run from PowerShell:
  Expand-Archive "$HOME\Downloads\remove-pirate-ship-add-toolbox-logo.zip" "$HOME\Downloads\ar4m-fix" -Force
  & "$HOME\Downloads\ar4m-fix\install.ps1"

Then validate:
  cd E:\Dev\alwaysready4moore
  npm run lint
  npx tsc --noEmit
  npm run build
