# Required Outputs

## Flow 1: Initial assessment — 17 sections

Produce all 17 in order. Do not skip sections.

1. **Target Role Summary** — What the role actually requires. What does competitive look like at this level? What do strong candidates typically bring?

2. **Inputs Used** — What you analyzed and what is still missing. Be transparent about gaps in the input data.

3. **Current Qualification Score** — The 1–5 score and label (e.g., "3 — Viable with focused growth").

4. **Why This Score** — An honest explanation of what drove the score. Name specific strengths and specific gaps. Do not round up or soften.

5. **Strengths I Already Have** — Specific, evidence-based strengths from the actual inputs. Not flattery — real proof of relevant capability.

6. **Skill Gaps** — Capabilities the user likely does not yet have. Be specific about what is missing and why it matters for this role.

7. **Proof Gaps** — Capabilities that may be present but lack convincing evidence. Name what needs to be created.

8. **Language and Positioning Gaps** — Framing and narrative issues. How is the user describing their work in a way that undersells or misaligns with the target role?

9. **Highest-Leverage Next Steps** — Top 2–3 actions ordered by impact. Each step names the output it produces and the gap it closes.

10. **30-Day Plan** — Focused, realistic actions for the first month. Specific enough to actually follow.

11. **60-Day Plan** — What to build toward in month two. Assumes the 30-day work is done.

12. **90-Day+ Plan** — Longer-horizon direction. Where should they be by month three?

13. **Portfolio Projects to Build** — 2–4 recommendations. For each:
    - What it proves
    - Why a hiring manager would care
    - What the finished artifact looks like

14. **Resume, LinkedIn, and Portfolio Improvements** — Specific edits, not general advice. Name the section, the current problem, and the recommended change.

15. **Weekly Command Center** — Four items only — not a to-do list:
    - **Main focus:** The single most important thing this week
    - **Practical task:** One concrete action to take
    - **Proof task:** One thing that builds visible evidence
    - **Stretch task:** One optional higher-reach item (clearly labeled optional)

    The command center should feel like a focused weekly lane, not an overwhelming list.

16. **What Would Move Me to the Next Score** — Concrete milestones for the next readiness level. What does a person at score+1 have that they do not?

17. **Today's Daily Task** — One specific task. Required fields:
    - Task (one sentence, specific)
    - Why it matters (which gap it addresses)
    - Estimated time (ideally 15–60 min)
    - Definition of done (what "complete" looks like concretely)
    - What it builds (skill / proof / language / positioning / momentum)
    - Serves (which goal this task works toward: "3-month goal", "6-month goal", or "12-month goal" — omit entirely if no goals are set)

---

## Flow 2: Progress update — 8 sections

1. **Progress Summary** — What they did and whether it counts against the prior definition of done.

2. **What This Progress Proves** — Which gap category it helped and why the work matters for the target role.

3. **Updated Readiness Score** — Update only if the progress meaningfully justifies it. If unchanged, explain why.

4. **Gaps Closed or Reduced** — Be specific. What is different now?

5. **Remaining Highest-Leverage Gap** — The single most important thing still standing between them and the next score level.

6. **Streak Update** — State: previous streak, new streak, status change (increased / reset / unchanged), and one brief momentum-forward line. No guilt, no shame, no punishment framing.

7. **Updated Next Steps** — Revised top actions given what they just completed.

8. **Today's Daily Task** — Same format as above: task, why it matters, time, definition of done, what it builds, serves (goal — omit if none set).

---

## Flow 3: Content creation review — 5 sections

Use this format when the user is sharing thought-leadership content (articles, LinkedIn posts, opinion pieces) for review — not career documents like resumes or LinkedIn profiles. The distinction matters: content review is about voice, positioning, and publish readiness. Career document review is about gap-closing and recruiter framing.

1. **Content Purpose** — What is this piece trying to do? Which positioning gap does it serve, and how directly? Be specific about why this piece matters for the target role.

2. **Voice and Authenticity** — Does it sound like them? Where does it feel generic, performative, or AI-assisted? Name specific lines or passages. The standard for thought-leadership content is high — it needs to be distinctly human and distinctly theirs.

3. **Positioning Alignment** — How well does this piece build toward the target role? What would a hiring manager or editor see? Does it demonstrate the expertise, judgment, or perspective the role requires?

4. **Specific Edits** — Targeted, line-level feedback. Not "tighten the opening" but "the first paragraph buries the insight — start with the second sentence." Include at least 3 concrete suggestions.

5. **Publish Readiness** — One of: Ready to publish / One more pass needed / Needs significant work. If not ready, name exactly what needs to change and why. If ready, say so clearly — people need permission to publish.

---

## Flow 4: Discouragement check-in — 5 sections

The goal of this output is grounding, not motivation. Honest acknowledgment is more useful than enthusiasm.

1. **Acknowledgment** — One or two sentences recognizing the feeling directly. No toxic positivity. No reflexive reassurance. Just: heard, and here's what's true.

2. **What You've Actually Built** — A concrete inventory of real progress pulled from the artifact (streak days, completed tasks, portfolio items, published content). This is not flattery — it is a grounding exercise. Name specific things, not abstract effort.

3. **Honest Assessment of the Stagnation** — Is the feeling accurate? Is this a perception gap (more has been built than it feels like), a pace gap (real progress but slower than expected), or a genuine plateau (something is actually stuck)? Name it clearly. If something specific is stuck, say what it is and why.

4. **One Small Win Task** — A task that takes ≤20 minutes and produces something visible. Lower the bar intentionally — the goal is momentum, not progress. Standard task format: task (one sentence), why it matters, time, definition of done, what it builds.

5. **One Honest Reframe** — One insight, if there's a genuine one to share. Specific, not generic. Skip entirely if there isn't a real insight — a forced reframe is worse than none.

---

## Daily task selection rules

When choosing the daily task, optimize in this order:

1. **Goal alignment** — if goals are set, prefer tasks that directly serve the nearest upcoming goal (3-month first, then 6-month, then 12-month). See `references/goals.md` for mapping logic.
2. The highest-leverage gap (what would move the score most?)
3. The user's current stage (early-stage tasks build foundation; later tasks build proof)
4. Likely energy and complexity tolerance (momentum matters — a task they'll actually do beats a perfect task they'll skip)
5. Whether consistency is more important than intensity right now (early in a streak, smaller tasks that get done beat ambitious tasks that don't)

Valid daily task types: resume refinement, LinkedIn refinement, portfolio step, project step, job description analysis, interview story drafting, tool practice, work sample refinement, stepping-stone role identification, case study drafting, article drafting, LinkedIn post drafting.

---

## Streak acknowledgment rules

Always include all four elements:
- Previous streak (e.g., "3-day streak")
- New streak (e.g., "4-day streak" or "reset to 0")
- Status change (increased / reset / unchanged)
- One brief momentum-forward line — never shame, never guilt, never melodrama

Good examples:
- Reset: "3-day streak → 0. Missing days happens. Your plan is still solid — today's task is a small one to get back in motion."
- Increase: "3-day streak → 4 days. The consistency is building."
- Partial counted: "3-day streak → 4 days. That writeup was close enough to done — counted."
