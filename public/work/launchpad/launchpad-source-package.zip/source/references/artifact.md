# Artifact Template

Generate self-contained HTML for the Launchpad command center artifact. Replace every `{{PLACEHOLDER}}` with real content. Do not leave any placeholder in the final output.

## Security: sanitizing user content

Before inserting any user-supplied value into HTML (role name, company, task text, gap items, strength items, streak status), escape these characters: `&` → `&amp;`, `<` → `&lt;`, `>` → `&gt;`, `"` → `&quot;`. This prevents broken HTML if a value contains those characters.

For `{{COMPLETED_DAYS}}`, `{{REST_DAYS}}`, `{{SCORE_HISTORY_JS}}`, and `{{CONTENT_PIPELINE_JS}}`: serialize as valid JSON arrays with double-quoted strings. Escape any literal double quotes inside strings as `\"`.

## Placeholders reference

| Placeholder | Content |
|---|---|
| {{TARGET_ROLE}} | e.g. "Senior Product Manager" |
| {{COMPANY}} | Company name, e.g. "Abnormal AI" |
| {{LOCATION}} | e.g. "Remote" or "San Francisco, CA" |
| {{SCORE}} | Number 1–5 (can be a decimal like 4.5) |
| {{SCORE_LABEL}} | e.g. "Viable with focused growth" |
| {{SCORE_PIPS}} | Five `<span class="lp-pip [filled]"></span>` elements; add class "filled" for each pip up to {{SCORE}} (round down for fractional scores) |
| {{STREAK}} | Number, e.g. "4" |
| {{STREAK_UNIT}} | "day" if streak is 1, "days" otherwise |
| {{STREAK_EMOJI}} | 🚀 for streak ≥ 1; 💤 for streak = 0 |
| {{STREAK_STATUS}} | One sentence on momentum — no shame, no guilt |
| {{COMPLETED_DAYS}} | JSON array of completed day objects — see Calendar section below |
| {{REST_DAYS}} | JSON array of day-of-week numbers for rest days — see Rest days section below |
| {{SCORE_HISTORY_JS}} | JS array of score history objects — see Score history section below |
| {{CONTENT_PIPELINE_JS}} | JS array of content pipeline items — see Content pipeline section below |
| {{LOGO_HTML}} | `<img src="./FILENAME.png" alt="Launchpad">` if a logo file exists in the artifact folder, otherwise `<div class="lp-brand-text">Launchpad</div>` |
| {{TASK_NAME}} | The daily task, one sentence |
| {{TASK_TIME}} | e.g. "~30 min" |
| {{TASK_BUILDS}} | e.g. "Proof gap" |
| {{TASK_WHY}} | One sentence on why it matters |
| {{TASK_DOD}} | Definition of done, one sentence |
| {{PORTFOLIO_BUILDS}} | 2–4 `<div class="lp-build-card">` blocks — see Portfolio builds section below |
| {{WEEKLY_MAIN}} | This week's main focus |
| {{WEEKLY_PRACTICAL}} | Practical task for the week |
| {{WEEKLY_PROOF}} | Proof-building task for the week |
| {{WEEKLY_STRETCH}} | Optional stretch task |
| {{GAP_SKILL_ITEMS}} | One `<li>` per skill gap; omit entire block if none |
| {{GAP_PROOF_ITEMS}} | One `<li>` per proof gap; omit entire block if none |
| {{GAP_LANG_ITEMS}} | One `<li>` per language/positioning gap; omit entire block if none |
| {{STRENGTH_ITEMS}} | One `<li>` per strength (3–5 items, specific and evidence-backed) |
| {{PLAN_30}} | 30-day plan summary, 1–2 sentences |
| {{PLAN_60}} | 60-day plan summary, 1–2 sentences |
| {{PLAN_90}} | 90-day+ plan summary, 1–2 sentences |
| {{GOAL_3M}} | 3-month goal text; empty string if not set |
| {{GOAL_6M}} | 6-month goal text; empty string if not set |
| {{GOAL_12M}} | 12-month goal text; empty string if not set |
| {{TASK_SERVES_GOAL}} | Which goal today's task serves, e.g. "3-month goal" — omit tag entirely if no goals set |
| {{CAREER_GOALS_JS}} | Full JS object literal for CAREER_GOALS — see Goals section below |
| {{DATE}} | Current date, e.g. "June 6, 2026" |

### Calendar: {{COMPLETED_DAYS}} format

Serialize as a JSON array. Each entry has two keys: `date` (ISO `"YYYY-MM-DD"`) and `task` (description of what was completed). On a new assessment, use `[]`. On each progress update, append the new entry — never remove prior entries.

Example:
```json
[
  {"date":"2026-06-06","task":"Full resume rewrite — rebuilt from scratch with content strategist framing."},
  {"date":"2026-06-07","task":"Published LinkedIn article on workplace conflict — first live external writing sample."}
]
```

### Rest days: {{REST_DAYS}} format

Array of day-of-week numbers (0=Sun, 1=Sun, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat). Rest days display with a subtle striped style in the calendar — they are not counted against the streak.

Examples: `[0, 6]` (standard Sat/Sun), `[1, 2]` (Mon/Tue off), `[5]` (Friday only), `[]` (no rest days).

### Score history: {{SCORE_HISTORY_JS}} format

Array of score history objects. Initialize with the first assessment. Append an entry each time the score changes — never remove prior entries.

```json
[
  {"date":"2026-06-06","score":4,"note":"Initial assessment"},
  {"date":"2026-07-08","score":4.5,"note":"Portfolio site shipped"}
]
```

When no prior history exists (new skill installs meeting existing users), initialize with a single entry using the current score and note "Initial assessment."

### Content pipeline: {{CONTENT_PIPELINE_JS}} format

Array of content pipeline items. Each entry tracks a piece of thought-leadership content at some stage of production. Add items when the user creates or shares content in Flow 3. Update status as pieces move from drafted → published → live.

```json
[
  {"title":"The Illusion of the Digital Magic Wand","type":"article","status":"drafted","url":""},
  {"title":"On introducing yourself as Marquetta","type":"linkedin-post","status":"drafted","url":""},
  {"title":"Navigating Spicy Users","type":"article","status":"live","url":"https://www.linkedin.com/pulse/..."}
]
```

Valid types: `article`, `linkedin-post`, `portfolio-piece`, `case-study`
Valid statuses: `drafted`, `published`, `live`
Initialize as `[]` if no content has been tracked yet.

### Portfolio builds: {{PORTFOLIO_BUILDS}} format

One `<div class="lp-build-card">` per project, up to 4. Priority label format: "Build 1 · Highest priority", "Build 2", "Build 3 · Stretch". Example:

```html
<div class="lp-build-card">
  <div class="lp-build-num">Build 1 · Highest priority</div>
  <div class="lp-build-title">Content transformation one-pager</div>
  <div class="lp-build-desc">What it proves and why a hiring manager would care.</div>
</div>
```

### Goals: {{GOAL_3M}}, {{GOAL_6M}}, {{GOAL_12M}}, {{CAREER_GOALS_JS}}

Three goal placeholders map to individual goal display cards. `{{CAREER_GOALS_JS}}` is the full serialized JS object used in the script block so Claude can read and update goals across sessions.

**If a goal is not yet set**, use an empty string for that placeholder and add class `lp-goal-empty` to the goal item so it renders in muted italic.

**`{{CAREER_GOALS_JS}}` format:**

```js
{
  threeMonth: "Publish 5 LinkedIn articles and complete the Content Strategist portfolio",
  sixMonth: "Reach 12-month tenure at Abnormal AI and be ready to reapply for Content Strategist",
  twelveMonth: "Land a Content Strategist role — internal or external"
}
```

When goals aren't set yet, use empty strings for all three keys.

## Full HTML template


```html
<!DOCTYPE html>
<script type="application/json" id="cowork-artifact-meta">
{
  "name": "Launchpad {{TARGET_ROLE}}",
  "schemaVersion": 1,
  "description": "Career readiness command center for {{TARGET_ROLE}} at {{COMPANY}}. Score: {{SCORE}}/5. Streak: {{STREAK}} {{STREAK_UNIT}}. Updated {{DATE}}."
}
</script>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Launchpad — {{TARGET_ROLE}}</title>
<style>
:root{color-scheme:light}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;background:#f9f9f9;color:#1a1a1a;padding:24px;min-height:100vh}
.lp{max-width:860px;margin:0 auto}
.lp-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:20px;padding-bottom:16px;border-bottom:1.5px solid #e5e5e5}
.lp-brand{margin-bottom:6px}
.lp-brand img{height:32px;width:auto;display:block}
.lp-brand-text{font-size:11px;font-weight:500;letter-spacing:.08em;color:#999;text-transform:uppercase;margin-bottom:4px}
.lp-role{font-size:21px;font-weight:600;color:#111;line-height:1.2}
.lp-company{font-size:13px;color:#666;margin-top:3px;display:flex;align-items:center;gap:5px}
.lp-score-block{text-align:right;flex-shrink:0;margin-left:20px}
.lp-score-row{display:flex;align-items:baseline;justify-content:flex-end;gap:2px}
.lp-score-num{font-size:40px;font-weight:600;line-height:1;color:#111}
.lp-score-denom{font-size:17px;color:#aaa;font-weight:400}
.lp-score-label{font-size:12px;color:#666;margin-top:4px}
.lp-score-pips{display:flex;gap:5px;justify-content:flex-end;margin-top:8px;margin-bottom:5px}
.lp-pip{width:26px;height:5px;border-radius:3px;background:#e5e5e5}
.lp-pip.filled{background:#111}
.lp-score-history{display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end;margin-top:5px}
.lp-score-hist-entry{font-size:11px;color:#aaa;display:flex;align-items:center;gap:3px}
.lp-score-hist-val{font-weight:600;color:#777}
.lp-score-hist-arrow{color:#ddd;margin:0 2px}
.lp-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.lp-full{grid-column:1/-1}
.lp-card{background:#fff;border-radius:12px;padding:16px;border:1px solid #ebebeb}
.lp-clabel{font-size:10px;font-weight:600;letter-spacing:.07em;text-transform:uppercase;color:#aaa;margin-bottom:10px}
.lp-task-name{font-size:15px;font-weight:600;margin-bottom:6px;line-height:1.35;color:#111}
.lp-task-meta{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}
.lp-tag{font-size:11px;font-weight:500;padding:2px 9px;border-radius:20px;background:#f2f2f2;color:#555;white-space:nowrap}
.lp-task-why{font-size:13px;color:#555;line-height:1.5;margin-bottom:6px}
.lp-dod{font-size:12px;color:#999;line-height:1.4}
.lp-streak-inner{display:flex;gap:32px;align-items:flex-start}
.lp-streak-left{flex-shrink:0;width:130px}
.lp-streak-num{font-size:52px;font-weight:700;line-height:1;color:#111;letter-spacing:-2px}
.lp-streak-unit{font-size:13px;color:#777;margin-top:2px}
.lp-streak-flame{font-size:22px;margin-top:6px}
.lp-streak-status{font-size:12px;color:#999;margin-top:8px;line-height:1.5}
.lp-cal-wrap{flex:1;min-width:0}
.lp-cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.lp-cal-month{font-size:13px;font-weight:600;color:#333;letter-spacing:.01em}
.lp-cal-legend{display:flex;align-items:center;gap:12px;font-size:10px;color:#bbb}
.lp-cal-legend-item{display:flex;align-items:center;gap:5px}
.lp-cal-legend-dot{width:10px;height:10px;border-radius:3px;flex-shrink:0}
.lp-cal-legend-dot.done{background:linear-gradient(135deg,#4f46e5,#7c3aed)}
.lp-cal-legend-dot.rest{background:repeating-linear-gradient(45deg,#ececec,#ececec 2px,#f5f5f5 2px,#f5f5f5 5px)}
.lp-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.lp-cal-dow{font-size:9px;font-weight:600;color:#ccc;text-align:center;padding-bottom:4px;letter-spacing:.04em;text-transform:uppercase}
.lp-cal-day{aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:12px;color:#bbb;border-radius:7px;cursor:default;transition:transform .15s ease,box-shadow .15s ease,background .15s ease;user-select:none;position:relative}
.lp-cal-day.has-num{color:#777}
.lp-cal-day.future{color:#ccc}
.lp-cal-day.rest{background:repeating-linear-gradient(45deg,#ececec,#ececec 2px,#f5f5f5 2px,#f5f5f5 5px);color:#ccc;border-radius:7px}
.lp-cal-day.today{color:#4f46e5;font-weight:700;background:rgba(79,70,229,.07)}
.lp-cal-day.rest.today{background:repeating-linear-gradient(45deg,#ececec,#ececec 2px,#f5f5f5 2px,#f5f5f5 5px);color:#9ca3af;font-weight:600;box-shadow:0 0 0 2px #c7d2fe}
.lp-cal-day.done{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;font-weight:600;cursor:pointer;box-shadow:0 2px 8px rgba(79,70,229,.28)}
.lp-cal-day.done:hover{transform:scale(1.15);box-shadow:0 4px 16px rgba(79,70,229,.45);z-index:2}
.lp-cal-day.done.today{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;box-shadow:0 2px 8px rgba(79,70,229,.28),0 0 0 2.5px #fff,0 0 0 4.5px #4f46e5}
.lp-cal-day.selected{box-shadow:0 0 0 2.5px #fff,0 0 0 4.5px #4f46e5 !important;transform:scale(1.12);z-index:3}
.lp-day-detail{margin-top:12px;padding:12px 14px;background:linear-gradient(135deg,rgba(79,70,229,.05),rgba(124,58,237,.05));border:1px solid rgba(79,70,229,.14);border-radius:10px;display:none;animation:lpFadeIn .18s ease}
@keyframes lpFadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
.lp-detail-date{font-size:10px;font-weight:700;color:#4f46e5;letter-spacing:.06em;text-transform:uppercase;margin-bottom:5px}
.lp-detail-badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;color:#16a34a;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:20px;padding:2px 8px;margin-bottom:7px}
.lp-detail-task{font-size:13px;color:#444;line-height:1.55}
.lp-week-row{display:flex;gap:10px;align-items:baseline;margin-bottom:9px}
.lp-week-row:last-child{margin-bottom:0}
.lp-week-tag{font-size:11px;font-weight:500;padding:2px 9px;border-radius:20px;background:#f2f2f2;color:#555;white-space:nowrap;flex-shrink:0}
.lp-week-text{font-size:13px;color:#555;line-height:1.5}
.lp-build-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:2px}
.lp-build-card{background:#f7f7f7;border-radius:8px;padding:12px}
.lp-build-num{font-size:10px;font-weight:700;color:#aaa;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em}
.lp-build-title{font-size:13px;font-weight:600;color:#111;margin-bottom:4px;line-height:1.3}
.lp-build-desc{font-size:12px;color:#666;line-height:1.5}
.lp-gaps-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.lp-gap-type{font-size:11px;font-weight:600;margin-bottom:7px;letter-spacing:.02em}
.lp-gap-type.skill{color:#3b6ef8}
.lp-gap-type.proof{color:#d97706}
.lp-gap-type.language{color:#666}
.lp-gap-list{list-style:none;padding:0}
.lp-gap-list li{font-size:13px;color:#555;line-height:1.5;padding-left:13px;position:relative;margin-bottom:5px}
.lp-gap-list li::before{content:"·";position:absolute;left:0;color:#bbb;font-size:16px;line-height:1.1}
.lp-strengths{list-style:none;padding:0}
.lp-strengths li{font-size:13px;color:#555;line-height:1.5;padding-left:18px;position:relative;margin-bottom:6px}
.lp-strengths li::before{content:"✓";position:absolute;left:0;color:#22c55e;font-size:11px;top:2px;font-weight:700}
.lp-plan-row{margin-bottom:11px}
.lp-plan-row:last-child{margin-bottom:0}
.lp-plan-period{font-size:10px;font-weight:600;color:#aaa;margin-bottom:3px;text-transform:uppercase;letter-spacing:.05em}
.lp-plan-text{font-size:13px;color:#555;line-height:1.5}
.lp-goals-list{display:flex;flex-direction:column;gap:6px}
.lp-goal-item{display:flex;gap:12px;align-items:flex-start;padding:10px 12px;background:#f7f7f7;border-radius:8px}
.lp-goal-period{font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;flex-shrink:0;width:68px;padding-top:2px}
.lp-goal-text{font-size:13px;color:#555;line-height:1.5}
.lp-goal-item.lp-goal-empty .lp-goal-text{color:#bbb;font-style:italic}
/* Content pipeline */
.lp-pipeline-list{display:flex;flex-direction:column;gap:7px}
.lp-pipeline-item{display:flex;align-items:center;gap:10px;padding:8px 10px;background:#f7f7f7;border-radius:8px}
.lp-pipeline-badge{font-size:10px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;padding:2px 8px;border-radius:20px;flex-shrink:0;white-space:nowrap}
.lp-pipeline-badge.drafted{background:#f2f2f2;color:#999}
.lp-pipeline-badge.published{background:#dbeafe;color:#1d4ed8}
.lp-pipeline-badge.live{background:#dcfce7;color:#15803d}
.lp-pipeline-type{font-size:10px;color:#bbb;flex-shrink:0;text-transform:uppercase;letter-spacing:.04em;width:80px}
.lp-pipeline-title{font-size:13px;color:#444;flex:1;line-height:1.4}
.lp-pipeline-link{font-size:12px;color:#4f46e5;text-decoration:none;flex-shrink:0}
.lp-pipeline-link:hover{text-decoration:underline}
.lp-footer{font-size:11px;color:#bbb;margin-top:20px;padding-top:12px;border-top:1px solid #ebebeb;text-align:right}
@media(max-width:620px){
  .lp-grid{grid-template-columns:1fr}.lp-full{grid-column:1}
  .lp-streak-inner{flex-direction:column;gap:20px}
  .lp-streak-left{width:auto}
  .lp-gaps-grid{grid-template-columns:1fr}
  .lp-build-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>
<h2 style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap">Launchpad career readiness command center for {{TARGET_ROLE}} at {{COMPANY}}</h2>

<div class="lp">
  <div class="lp-header">
    <div>
      <div class="lp-brand">{{LOGO_HTML}}</div>
      <div class="lp-role">{{TARGET_ROLE}}</div>
      <div class="lp-company">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1500 1500" width="14" height="14" style="flex-shrink:0" aria-hidden="true"><rect width="1500" height="1500" fill="#c7e913"/><path d="M483.4,392.1h127.8l-226.9,715.1h-127.5l226.6-715.1h0ZM611.2,392.1l226.9,715.1h127.5l-226.6-715.1h-127.8ZM1015.3,392h-128.4l227.8,715.9h128.4l-227.8-715.9h0Z"/></svg>
        {{COMPANY}} · {{LOCATION}}
      </div>
    </div>
    <div class="lp-score-block">
      <div class="lp-score-row">
        <span class="lp-score-num">{{SCORE}}</span>
        <span class="lp-score-denom">/5</span>
      </div>
      <div class="lp-score-pips">{{SCORE_PIPS}}</div>
      <div class="lp-score-label">{{SCORE_LABEL}}</div>
      <div class="lp-score-history" id="score-history"></div>
    </div>
  </div>

  <div class="lp-grid">

    <div class="lp-card">
      <div class="lp-clabel">Today's task</div>
      <div class="lp-task-name">{{TASK_NAME}}</div>
      <div class="lp-task-meta">
        <span class="lp-tag">{{TASK_TIME}}</span>
        <span class="lp-tag">{{TASK_BUILDS}}</span>
        {{TASK_SERVES_GOAL_TAG}}
      </div>
      <div class="lp-task-why">{{TASK_WHY}}</div>
      <div class="lp-dod">Done when: {{TASK_DOD}}</div>
    </div>

    <div class="lp-card lp-full">
      <div class="lp-clabel">Career goals</div>
      <div class="lp-goals-list">
        <div class="lp-goal-item{{GOAL_3M_EMPTY}}">
          <div class="lp-goal-period">3 months</div>
          <div class="lp-goal-text">{{GOAL_3M_TEXT}}</div>
        </div>
        <div class="lp-goal-item{{GOAL_6M_EMPTY}}">
          <div class="lp-goal-period">6 months</div>
          <div class="lp-goal-text">{{GOAL_6M_TEXT}}</div>
        </div>
        <div class="lp-goal-item{{GOAL_12M_EMPTY}}">
          <div class="lp-goal-period">12 months</div>
          <div class="lp-goal-text">{{GOAL_12M_TEXT}}</div>
        </div>
      </div>
    </div>

    <div class="lp-card lp-full">
      <div class="lp-clabel">Streak</div>
      <div class="lp-streak-inner">
        <div class="lp-streak-left">
          <div class="lp-streak-num">{{STREAK}}</div>
          <div class="lp-streak-unit">{{STREAK_UNIT}}</div>
          <div class="lp-streak-flame">{{STREAK_EMOJI}}</div>
          <div class="lp-streak-status">{{STREAK_STATUS}}</div>
        </div>
        <div class="lp-cal-wrap">
          <div class="lp-cal-header">
            <span class="lp-cal-month" id="cal-month-label"></span>
            <span class="lp-cal-legend">
              <span class="lp-cal-legend-item">
                <span class="lp-cal-legend-dot done"></span>
                completed
              </span>
              <span class="lp-cal-legend-item">
                <span class="lp-cal-legend-dot rest"></span>
                rest day
              </span>
            </span>
          </div>
          <div class="lp-cal-grid" id="cal-grid"></div>
          <div class="lp-day-detail" id="day-detail">
            <div class="lp-detail-date" id="detail-date"></div>
            <div class="lp-detail-badge">&#10003; Completed</div>
            <div class="lp-detail-task" id="detail-task"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="lp-card lp-full" id="content-pipeline-card" style="display:none">
      <div class="lp-clabel">Content pipeline</div>
      <div class="lp-pipeline-list" id="pipeline-list"></div>
    </div>

    <div class="lp-card lp-full">
      <div class="lp-clabel">Portfolio build queue</div>
      <div class="lp-build-grid">
        {{PORTFOLIO_BUILDS}}
      </div>
    </div>

    <div class="lp-card lp-full">
      <div class="lp-clabel">This week</div>
      <div class="lp-week-row">
        <span class="lp-week-tag">Main focus</span>
        <span class="lp-week-text">{{WEEKLY_MAIN}}</span>
      </div>
      <div class="lp-week-row">
        <span class="lp-week-tag">Practical</span>
        <span class="lp-week-text">{{WEEKLY_PRACTICAL}}</span>
      </div>
      <div class="lp-week-row">
        <span class="lp-week-tag">Proof</span>
        <span class="lp-week-text">{{WEEKLY_PROOF}}</span>
      </div>
      <div class="lp-week-row">
        <span class="lp-week-tag">Stretch</span>
        <span class="lp-week-text">{{WEEKLY_STRETCH}}</span>
      </div>
    </div>

    <div class="lp-card lp-full">
      <div class="lp-clabel">Gaps</div>
      <div class="lp-gaps-grid">
        <div>
          <div class="lp-gap-type skill">Skill gaps</div>
          <ul class="lp-gap-list">{{GAP_SKILL_ITEMS}}</ul>
        </div>
        <div>
          <div class="lp-gap-type proof">Proof gaps</div>
          <ul class="lp-gap-list">{{GAP_PROOF_ITEMS}}</ul>
        </div>
        <div>
          <div class="lp-gap-type language">Language / positioning</div>
          <ul class="lp-gap-list">{{GAP_LANG_ITEMS}}</ul>
        </div>
      </div>
    </div>

    <div class="lp-card">
      <div class="lp-clabel">Strengths</div>
      <ul class="lp-strengths">{{STRENGTH_ITEMS}}</ul>
    </div>

    <div class="lp-card">
      <div class="lp-clabel">Roadmap</div>
      <div class="lp-plan-row">
        <div class="lp-plan-period">30 days</div>
        <div class="lp-plan-text">{{PLAN_30}}</div>
      </div>
      <div class="lp-plan-row">
        <div class="lp-plan-period">60 days</div>
        <div class="lp-plan-text">{{PLAN_60}}</div>
      </div>
      <div class="lp-plan-row">
        <div class="lp-plan-period">90 days+</div>
        <div class="lp-plan-text">{{PLAN_90}}</div>
      </div>
    </div>

  </div>

  <div class="lp-footer">Last updated {{DATE}}</div>
</div>

<script>
// COMPLETED_DAYS: append a new entry on each completed task. Never remove prior entries.
// Each entry: {"date":"YYYY-MM-DD","task":"Description of what was completed."}
const COMPLETED_DAYS = {{COMPLETED_DAYS}};

// REST_DAYS: day-of-week numbers for the user's off days (0=Sun,1=Mon,...,6=Sat).
// These days display as striped in the calendar and never break the streak.
// Default [0,6] = standard Sat/Sun weekend. Update when user specifies custom rest days.
const REST_DAYS = {{REST_DAYS}};

// CAREER_GOALS: three-timeframe career goals. Update when user confirms goal changes.
// Use empty strings for goals not yet set.
const CAREER_GOALS = {{CAREER_GOALS_JS}};

// SCORE_HISTORY: append an entry each time the score changes. Never remove prior entries.
// {date:"YYYY-MM-DD", score: 4.5, note:"Why the score changed"}
const SCORE_HISTORY = {{SCORE_HISTORY_JS}};

// CONTENT_PIPELINE: content pieces at different stages (drafted/published/live).
// Add entries in Flow 3 when new content is created or published.
// {title:"...", type:"article|linkedin-post|portfolio-piece|case-study", status:"drafted|published|live", url:""}
const CONTENT_PIPELINE = {{CONTENT_PIPELINE_JS}};

(function renderScoreHistory() {
  const el = document.getElementById('score-history');
  if (!el || SCORE_HISTORY.length < 2) return;
  el.innerHTML = SCORE_HISTORY.map((h, i) => {
    const arrow = i > 0 ? '<span class="lp-score-hist-arrow">→</span>' : '';
    return arrow + '<span class="lp-score-hist-entry" title="' + h.note + '"><span class="lp-score-hist-val">' + h.score + '</span></span>';
  }).join('');
})();

(function renderPipeline() {
  const card = document.getElementById('content-pipeline-card');
  const list = document.getElementById('pipeline-list');
  if (!card || !list || !CONTENT_PIPELINE.length) return;
  card.style.display = '';
  list.innerHTML = CONTENT_PIPELINE.map(item => {
    const link = item.url ? '<a class="lp-pipeline-link" href="' + item.url + '" target="_blank" rel="noopener">View →</a>' : '';
    const typeLabel = item.type.replace(/-/g, ' ');
    return '<div class="lp-pipeline-item">' +
      '<span class="lp-pipeline-badge ' + item.status + '">' + item.status + '</span>' +
      '<span class="lp-pipeline-type">' + typeLabel + '</span>' +
      '<span class="lp-pipeline-title">' + item.title + '</span>' +
      link +
      '</div>';
  }).join('');
})();

(function buildCalendar() {
  const today    = new Date();
  const year     = today.getFullYear();
  const month    = today.getMonth();
  const todayStr = today.toISOString().slice(0, 10);

  const MONTH_NAMES = ['January','February','March','April','May','June',
                       'July','August','September','October','November','December'];
  const DOWS = ['Su','Mo','Tu','We','Th','Fr','Sa'];

  const doneMap  = {};
  COMPLETED_DAYS.forEach(d => { doneMap[d.date] = d.task; });
  const restSet  = new Set(REST_DAYS);

  document.getElementById('cal-month-label').textContent =
    MONTH_NAMES[month] + ' ' + year;

  const grid        = document.getElementById('cal-grid');
  const detailPanel = document.getElementById('day-detail');
  const detailDate  = document.getElementById('detail-date');
  const detailTask  = document.getElementById('detail-task');
  let   selectedEl  = null;

  DOWS.forEach(d => {
    const el = document.createElement('div');
    el.className = 'lp-cal-dow';
    el.textContent = d;
    grid.appendChild(el);
  });

  const firstDow    = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDow; i++) {
    const el = document.createElement('div');
    el.className = 'lp-cal-day';
    grid.appendChild(el);
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = year + '-' +
      String(month + 1).padStart(2,'0') + '-' +
      String(d).padStart(2,'0');

    const dow      = new Date(year, month, d).getDay();
    const el       = document.createElement('div');
    const isDone   = !!doneMap[dateStr];
    const isRest   = restSet.has(dow) && !isDone;
    const isToday  = dateStr === todayStr;
    const isFuture = dateStr > todayStr;

    let cls = 'lp-cal-day has-num';
    if (isDone)   cls += ' done';
    if (isRest)   cls += ' rest';
    if (isToday)  cls += ' today';
    if (isFuture && !isDone && !isRest) cls += ' future';
    el.className  = cls;
    el.textContent = d;
    el.dataset.date = dateStr;

    if (isRest && !isDone) {
      el.setAttribute('title', 'Rest day');
      el.setAttribute('aria-label', 'Rest day ' + dateStr);
    }

    if (isDone) {
      el.setAttribute('role', 'button');
      el.setAttribute('tabindex', '0');
      el.setAttribute('aria-label', 'View task for ' + dateStr);

      function openDetail() {
        if (selectedEl && selectedEl !== el) selectedEl.classList.remove('selected');
        if (selectedEl === el) {
          el.classList.remove('selected');
          detailPanel.style.display = 'none';
          selectedEl = null;
          return;
        }
        selectedEl = el;
        el.classList.add('selected');
        const parts = dateStr.split('-');
        const dt = new Date(+parts[0], +parts[1]-1, +parts[2]);
        detailDate.textContent = dt.toLocaleDateString('en-US',
          { weekday:'long', month:'long', day:'numeric', year:'numeric' });
        detailTask.textContent = doneMap[dateStr];
        detailPanel.style.display = 'block';
        detailPanel.style.animation = 'none';
        detailPanel.offsetHeight;
        detailPanel.style.animation = '';
      }

      el.addEventListener('click', openDetail);
      el.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDetail(); }
      });
    }

    grid.appendChild(el);
  }
})();
</script>
</body>
</html>
```

## Notes for generation

- **{{SCORE_PIPS}}**: exactly 5 `<span>` elements; add class `filled` on the first N where N = floor(score). For a score of 4.5, fill 4 pips.
- **{{REST_DAYS}}**: pull from prior artifact if updating; default `[0,6]` for new assessments unless user specified otherwise.
- **{{CAREER_GOALS_JS}}**: pull from prior artifact if updating. On new assessment, populate after user confirms goals (or initialize with empty strings if goals not yet collected). Format: `{threeMonth:"...",sixMonth:"...",twelveMonth:"..."}`.
- **{{SCORE_HISTORY_JS}}**: pull from prior artifact if updating. On new assessment, initialize with the current score. On each score change, append. Format: `[{date:"YYYY-MM-DD",score:N,note:"..."}]`.
- **{{CONTENT_PIPELINE_JS}}**: pull from prior artifact if updating. Initialize as `[]` if no content tracked yet. Add/update entries in Flow 3.
- **Goal display placeholders**: `{{GOAL_3M_TEXT}}` / `{{GOAL_6M_TEXT}}` / `{{GOAL_12M_TEXT}}` — the goal text strings. `{{GOAL_3M_EMPTY}}` / `{{GOAL_6M_EMPTY}}` / `{{GOAL_12M_EMPTY}}` — add ` lp-goal-empty` (with leading space) when the corresponding goal is not set, otherwise empty string.
- **{{TASK_SERVES_GOAL_TAG}}**: when a goal is set and the task serves one, render `<span class="lp-tag">→ 3-month goal</span>` (adjust timeframe). When no goals are set, render nothing (empty string).
- **Content pipeline card**: hidden by default (`style="display:none"`); the JS shows it only if `CONTENT_PIPELINE` has entries. This keeps the artifact clean for users with no content yet.
- **Score history**: rendered only when there are 2+ entries (the JS skips it for a fresh assessment with a single entry).
- **Gap blocks**: omit any gap block entirely if it has no items.
- **{{LOGO_HTML}}**: prefer `<img>` if a logo file is known to exist in the artifact folder; fall back to `<div class="lp-brand-text">Launchpad</div>`.
- **Strengths**: 3–5 items, specific and evidence-backed — not flattery.
- **Portfolio builds**: 2–4 items from section 13 of the Flow 1 output. Prioritize the highest-leverage build.
- **Streak card is always full-width** (`lp-full`).
- The `<h2>` accessibility element at the top is required — keep it.
- Do not regenerate the artifact for Flow 3 (materials improvement or content review) unless the score or gap breakdown changed — do update `CONTENT_PIPELINE` data.
