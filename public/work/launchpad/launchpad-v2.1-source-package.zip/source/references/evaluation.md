# Evaluation Logic

## Readiness scoring scale

| Score | Label |
|-------|-------|
| 1 | Not currently competitive |
| 2 | Early alignment |
| 3 | Viable with focused growth |
| 4 | Strong candidate |
| 5 | Standout candidate |

**Half-scores** (e.g. 4.5) are permitted when a user is meaningfully between two levels — real progress has been made but a specific milestone remains. Use the format: `N.5 — [lower label], approaching [upper label]`. Example: `4.5 — Strong candidate, approaching standout`. Artifact pips round down (4.5 shows 4 filled pips).

**Score based on:** relevant experience, transferable skills, demonstrated outputs, quality of proof, relevance of portfolio, clarity of narrative, likely competitiveness against real candidates, and material alignment to the target role.

**Do not score based on:** keyword matching alone, title matching alone, flattering assumptions, or user optimism alone.

## Evidence priority order

Weight evidence in this order when evaluating readiness:

1. Direct work proof — portfolio artifacts, case studies, work samples, project deliverables, GitHub
2. Resume
3. LinkedIn
4. Self-description and notes

Strong proof in tier 1 can move the score up. Weak or absent tier 1 proof is often the single biggest gap, even when tier 2–4 look polished.

## The four-gap framework

Classify every issue into one of these types. The type determines the recommendation.

**Skill gap** — The user likely does not yet have the needed capability or depth. Closing it requires learning, practice, or experience-building. Don't recommend portfolio work when the underlying skill is genuinely missing.

**Proof gap** — The user likely has the capability or related experience, but lacks convincing evidence. Closing it requires creating visible artifacts — not more learning. This is the most common gap and the most fixable.

**Language gap** — The user has done the right kind of work but is not describing it effectively. The evidence exists; the framing is weak, vague, or generic. Closing it requires rewriting, not rebuilding.

**Positioning gap** — The user's overall materials do not tell a coherent story for the target role. Even good individual bullets don't add up. Closing it requires narrative restructuring across the materials.

This classification directly shapes what you recommend. A proof gap calls for case study work, not another certification. A language gap calls for rewriting, not new projects.

## Grounded guidance rules

All recommendations must be:
- **Role-specific** — tied to what this role actually requires
- **User-specific** — built from their actual background, not generic templates
- **Actionable** — leads to a concrete artifact or outcome
- **Realistic** — completable given their stage and likely constraints
- **Prioritized** — highest-leverage gap first

Every strong recommendation answers: what is the finished artifact, and why would a hiring manager care about it?

**Weak guidance to avoid** (unless made concrete):
- "Network more"
- "Take a course"
- "Learn more about X"
- "Build your brand"
- "Just apply"

**Strong guidance examples:**
- "Rewrite the second bullet in your current role to show cross-functional ownership — name the other teams, the decision, and the result"
- "Write a one-page case study on the process improvement you led in Q3 — what broke, what you changed, what improved"
- "Build a simple dashboard showing your analysis approach on a public dataset relevant to this role — 2-3 charts, brief methodology notes"
- "Rewrite your LinkedIn headline to name the exact function you're targeting and the value you bring to it"

## Edge cases

**Strong branding, weak proof:** Call out the lack of evidence directly. Great positioning can only take a score so far without underlying artifacts.

**Weak materials, likely strong capability:** Separate the proof gap cost from a skill gap cost. A capable person with bad framing needs rewriting help, not a career pivot.

**Conflicting inputs:** Note the inconsistency and explain how it reduces confidence in the score. Example: resume claims one thing, portfolio suggests another.

**Partial inputs:** Still score and advise. Explicitly note what is missing and what it would change about the assessment.

**Stretch role:** If the role requires a leap that is genuinely out of reach now, say so clearly. Identify 1–3 stepping-stone roles and create a bridge path. Still assign a useful daily task. Never stop at "not yet."

**Multiple target roles:** Compare separately if the roles are meaningfully different. If they share a core skill set, identify the strongest common denominator and note which role is the better fit given current state.

**User wants fast transformation:** Keep recommendations realistic and staged. Name the constraint honestly — "closing this skill gap typically takes 3–6 months of deliberate practice" — and build a plan that makes real progress in that window.
