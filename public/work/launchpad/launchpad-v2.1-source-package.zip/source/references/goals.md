# Career Goals

Career goals give Launchpad a directional anchor for daily tasks and roadmap planning. Without goals the skill works fine — but with them, every daily task can be tuned to a specific milestone instead of just "general progress," and the roadmap becomes a real plan instead of a generic one.

## Goal timeframes

Three timeframes, each with a specific milestone:

- **3 months** — The most concrete and near-term. Should be achievable with consistent daily effort. Typically: a portfolio milestone, a number of published pieces, a skill acquired, a credential earned, or a readiness threshold reached.
- **6 months** — A readiness or positioning milestone. Typically: being interview-ready, reaching a qualification threshold (like tenure), completing a major project, or landing a first application.
- **12 months** — The career positioning horizon. Typically: landing a specific role, reaching a title, or being established in a new function.

Good goals are:
- Specific enough to be testable ("Land a Content Strategist role" beats "get better at content")
- Realistic given the current readiness score and the user's constraints
- Sequenced so the 3-month goal feeds the 6-month one, and the 6-month feeds the 12-month

## Collecting goals

**In Flow 1**, after producing the full assessment, ask:

> "Do you have 3, 6, and 12-month career goals in mind? If so, share them and I'll tune your daily tasks and roadmap to hit them. If not, I can suggest goals based on your assessment."

- If the user provides goals: validate that they're realistic given the score and constraints; note any adjustments needed; store them.
- If the user says no or defers: generate suggested goals using the process below, present them, and ask the user to confirm or adjust before storing.
- If the user already shared goals before the assessment: use them directly; confirm them in the output.

**In Flow 2**, do not re-ask for goals. Read them from the `CAREER_GOALS` object in the existing artifact HTML. Only update goals if the user explicitly asks to change one.

**In Flow 3 (materials improvement and content creation)**: goals are read-only — use them as context for recommendations but don't prompt to update.

## Creating goals when the user doesn't have them

Base suggested goals on:
1. The current readiness score and what score+1 concretely requires
2. The most critical gaps from the assessment
3. Any constraints the user mentioned (time, budget, tenure requirements, life circumstances, competing priorities)
4. The 30/60/90-day roadmap already produced

Suggested goal structure — adapt to the user's situation:
- **3-month**: Complete the most urgent portfolio item and close one major gap
- **6-month**: Be ready to apply for the target role (resume, portfolio, and materials interview-ready)
- **12-month**: Land the role — or the stepping-stone role if the target is a stretch

Present as suggestions, not assignments. The user confirms or adjusts before they are stored.

## Goal storage format

Store goals in the artifact as a JS object. This allows Claude to read and update them across sessions by parsing the artifact HTML.

```js
const CAREER_GOALS = {
  threeMonth: "Publish 5 LinkedIn articles and complete the Content Strategist portfolio",
  sixMonth: "Reach 12-month tenure at Abnormal AI and be ready to reapply for Content Strategist",
  twelveMonth: "Land a Content Strategist role — internal or external"
};
```

If goals are not yet set, use empty strings:

```js
const CAREER_GOALS = {
  threeMonth: "",
  sixMonth: "",
  twelveMonth: ""
};
```

When a user confirms or updates a goal, regenerate the full artifact with the updated `CAREER_GOALS` object.

## Mapping daily tasks to goals

When selecting the daily task, tag it to the nearest goal it most directly serves:

- If the task closes a gap blocking the **3-month goal**: tag "3-month goal"
- If it's further out: tag "6-month goal" or "12-month goal"
- If no goals are set: omit the Serves field entirely from the output
- Prioritize tasks that serve the **nearest upcoming goal** first — the 3-month goal has priority over the 6-month, the 6-month has priority over the 12-month, unless the 3-month is already on track

Include the goal tag in daily task output:
- In chat output: add a "Serves" line to the daily task fields (after "What it builds")
- In the artifact: populate `{{TASK_SERVES_GOAL}}` in the task metadata tags
