DAMALI STREET NOTEBOOK PREVIEW V9

Copy app/ into the project root.

Preview:
http://localhost:3000/lab/damali-street-preview

V9 layout fix:
- Removes the large signature block from the page flow
- Places a small signature stamp beside the action buttons
- Pulls the Actual Experiment note upward
- Reduces spacing before the proof section
- Removes the large dead zone on the left notebook page

The live /lab/damali-street route remains untouched.
